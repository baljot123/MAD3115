//
//  ViewController.swift
//  day 6
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var txtcarcolor: UITextField!
    
    
    @IBOutlet weak var txtcarplate: UITextField!
    
    
    @IBAction func btnaddnewAction(_ sender: Any) {
        
        self.writePropertylist()
    }
    
    
    @IBAction func btnlistAllAction(_ sender: Any) {
        
        
    }
    
    
    func writePropertylist()
    {
        let mycar = NSMutableDictionary()
        mycar["CarPlate"] = self.txtcarplate.text
        mycar["CarColor"] = self.txtcarcolor.text
        if let plispath = Bundle.main.path(forResource: "car", ofType: "plist")
        {
            let carplist = NSMutableArray(contentsOfFile: plispath)
            carplist?.add(mycar)
            if ( carplist?.write(toFile: plispath, atomically: true))!
          {
            
            print("carslist : \(String(describing: carplist))")
            
            }
        }
            
        else{
            print("unable to locate plist file")
        }


}
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

